#include "fonctions.h"
#define EVENT_WAIT_MASK   (0x1)

int write_in_queue(RT_QUEUE *msgQueue, void * data, int size);

void watchdog(void * arg);

void envoyer(void * arg) {
    DMessage *msg;
    int err;

    while (1) {
        rt_printf("tenvoyer : Attente d'un message\n");
        if ((err = rt_queue_read(&queueMsgGUI, &msg, sizeof (DMessage), TM_INFINITE)) >= 0) {
            rt_printf("tenvoyer : envoi d'un message au moniteur\n");
            serveur->send(serveur, msg);
            msg->free(msg);
        } else {
            rt_printf("Error msg queue write: %s\n", strerror(-err));
        }
    }
}

void connecter(void * arg) { 
    int status;
    int err;
    DMessage *message;
    int i ; 

    rt_printf("tconnect : Debut de l'exécution de tconnect\n");

    while (1) {
        rt_printf("tconnect : Attente du sémarphore semConnecterRobot\n");
        rt_sem_p(&semConnecterRobot, TM_INFINITE);
        rt_printf("tconnect : Ouverture de la communication avec le robot\n");
        
        status = robot->open_device(robot);
        
		if (status == STATUS_OK) {
			status = robot->start_insecurely(robot);
			//marche aussi, mais moins bien avec robot->start(robot) ; 	
				if (status == STATUS_OK) {
					rt_printf("tconnect : Connexion robot OK \n");
					if (rt_event_signal(&ev_desc,(0x1))) {
							rt_printf("Envoi du flag impossible : arrêt du programme\n");
							exit(-1);
					}
				}	
				else {
					rt_printf("tconnect : Erreur dans robot_start\n");
				}
		}			
		else {
			rt_printf("tconnect : Erreur dans open_device \n");
		} 
			 

	   
        message = d_new_message();
        message->put_state(message, status);
        message->print(message, 100);

        if (write_in_queue(&queueMsgGUI, message, sizeof (DMessage)) < 0) {
            message->free(message);
        }
    }
}

void communiquer(void *arg) { 
    DMessage *msg = d_new_message();
    int status = 1;
    int num_msg = 0;


	while(1) {
    rt_printf("tserve error: ‘semConnexr : Début de l'exécution de serveur\n");
    serveur->open(serveur, "8000");
    rt_printf("tserver : Connexion...\n");    
    rt_sem_v(&semConnectionMoniteur) ; 
    rt_printf("tserver : Connexion avec le moniteur etablie !\n");

	    while (status > 0) {
		   rt_printf("tserver : Attente d'un message\n");
		   status = serveur->receive(serveur, msg);
		   
		   
		   if (status > 0) {
			num_msg++;
		       switch (msg->get_type(msg)) {
		           case MESSAGE_TYPE_ACTION:
		               rt_printf("tserver : Le message %d reçu est une action\n", num_msg);
		               DAction *action = d_new_action();
		               action->from_message(action, msg);
		               switch (action->get_order(action)) {
		                   case ACTION_CONNECT_ROBOT:
		                       rt_printf("tserver : Action connecter robot\n");
		                       rt_sem_v(&semConnecterRobot);
		                       break;
		                   case ACTION_FIND_ARENA:
		                       rt_printf("tserver : Action find arena\n");
		                       rt_sem_p(&semImage, TM_INFINITE) ; 
		                       rt_sem_v(&semArena);
		                       break;
		                   case ACTION_ARENA_FAILED:
		                       rt_printf("tserver : Action arena failed\n");
		                       rt_sem_v(&semImage);
						   arena = NULL ; 
		                       break;
		                   case ACTION_ARENA_IS_FOUND:
		                       rt_printf("tserver : Action arena found\n"); 
							rt_sem_v(&semImage);
		                       break;
		                   case ACTION_COMPUTE_CONTINUOUSLY_POSITION:
		                       rt_printf("tserver : Action compute\n");
						  	rt_mutex_acquire(&mutexPosition, TM_INFINITE);
							computePosition = 1 ;
							rt_mutex_release(&mutexPosition);
		                       break;
		                    case ACTION_STOP_COMPUTE_POSITION:
		                       rt_printf("tserver : Action stop compute\n");
							rt_mutex_acquire(&mutexCompteur, TM_INFINITE);
							computePosition = 0 ;
							rt_mutex_release(&mutexCompteur);
						break ; 
		                     
		               }
		               break;
		           case MESSAGE_TYPE_MOVEMENT:
		               rt_printf("tserver : Le message reçu %d est un mouvement\n", num_msg);
		               rt_mutex_acquire(&mutexMove, TM_INFINITE);
		               move->from_message(move, msg);
		               move->print(move);
		               rt_mutex_release(&mutexMove);
		               break;
		       }
		}
		else {
				rt_printf("tserver : Connexion avec le moniteur rompue\n");
			   rt_sem_p(&semConnectionMoniteur, TM_INFINITE) ; 
			   serveur->close(serveur) ; 
		}
	    }
    }
}


void battery (void* arg){ 
	int status;
	DMessage *message ; 
	DBattery * sbattery = d_new_battery();
	
	unsigned long mask_ret;
	int vbat ;
	rt_printf("tbattery : Debut de l'éxecution de periodique à 250ms\n");
	rt_task_set_periodic(NULL, TM_NOW, 250000000); //périodique de 250ms
	while(1) {
	
	    	rt_task_wait_period(NULL); 
	    	rt_event_wait(&ev_desc,EVENT_WAIT_MASK,&mask_ret,EV_ANY,TM_INFINITE);
	   	status = robot->get_vbat(robot, (&vbat));
		rt_printf("tbattery : status = %d\n", status) ; 
        	
        	if (status == STATUS_OK) {
		  	rt_mutex_acquire(&mutexCompteur, TM_INFINITE);
		     compteur = 0 ;
		     rt_mutex_release(&mutexCompteur);
		     
            	sbattery->set_level(sbattery, vbat);
            	message = d_new_message();
	          message->put_battery_level(message,sbattery);
	          message->print(message, 100) ; 
            	rt_printf("tbattery : Envoi message\n");
               
               if (write_in_queue(&queueMsgGUI, message, sizeof (DMessage)) < 0) {
		 		message->free(message);
		  	}           
         }
       else {
			rt_mutex_acquire(&mutexCompteur, TM_INFINITE);
			compteur++ ;
			rt_printf("tbattery : compteur = %d\n", compteur) ; 
			rt_mutex_release(&mutexCompteur);
       }
  }
}     


void deplacer(void *arg) {
    int status = 1;
    int gauche;
    int droite;
    int lent ; 
    //int compteur = 0 ; 
    DMessage *message;
	unsigned long mask_ret;
    rt_printf("tmove : Debut de l'éxecution de periodique à 1s\n");
    rt_task_set_periodic(NULL, TM_NOW, 1000000000);

    while (1) {
        /* Attente de l'activation périodique */
        rt_task_wait_period(NULL);
        rt_event_wait(&ev_desc,EVENT_WAIT_MASK,&mask_ret,EV_ANY,TM_INFINITE);
        rt_printf("tmove : Activation périodique\n");

		  rt_mutex_acquire(&mutexMove, TM_INFINITE);
		  switch (move->get_direction(move)) {
		      case DIRECTION_FORWARD:
		          gauche = MOTEUR_ARRIERE_LENT;
		          droite = MOTEUR_ARRIERE_LENT;
		          break;
		      case DIRECTION_LEFT:
		          gauche = MOTEUR_ARRIERE_LENT;
		          droite = MOTEUR_AVANT_LENT;
		          break;
		      case DIRECTION_RIGHT:
		          gauche = MOTEUR_AVANT_LENT;
		          droite = MOTEUR_ARRIERE_LENT;
		          break;
		      case DIRECTION_STOP:
		          gauche = MOTEUR_STOP;
		          droite = MOTEUR_STOP;
		          break;
		      case DIRECTION_STRAIGHT:
		          gauche = MOTEUR_AVANT_LENT;
		          droite = MOTEUR_AVANT_LENT;
		          break;
		  }
		  rt_mutex_release(&mutexMove);

	       status = robot->set_motors(robot, gauche, droite);
	       if (status == STATUS_OK) { 
	         		 rt_mutex_acquire(&mutexCompteur, TM_INFINITE);
		           compteur = 0 ;
		           rt_mutex_release(&mutexCompteur); 		       
	       }
	       else {
		  		rt_mutex_acquire(&mutexCompteur, TM_INFINITE);
		          compteur++ ;
         			rt_printf("tmove : compteur = %d\n", compteur) ; 
		          rt_mutex_release(&mutexCompteur);
	       }

           message = d_new_message();
           message->put_state(message, status);

           rt_printf("tmove : Envoi message\n");
           if (write_in_queue(&queueMsgGUI, message, sizeof (DMessage)) < 0) {
               message->free(message);
           }
    }
}

void watchdog(void * arg) {
	int status;
	DMessage *message;
	unsigned long mask_ret;	
	
	rt_printf("twatchdog : Debut de l'éxecution de periodique à 1s\n");
    	rt_task_set_periodic(NULL, TM_NOW, 1000000000);
	 
    	 while (1) {
        /* Attente de l'activation périodique */
        rt_event_wait(&ev_desc,EVENT_WAIT_MASK,&mask_ret,EV_ANY,TM_INFINITE);
        rt_task_wait_period(NULL);
        rt_printf("twatchdog : Activation périodique\n");
			
       		status = robot->reload_wdt(robot);
       		if (status == STATUS_OK) { 
		  		rt_printf("twatchdog : RELOAD ENVOYE\n"); 
		  		rt_mutex_acquire(&mutexCompteur, TM_INFINITE);
		          compteur = 0 ;
		          rt_mutex_release(&mutexCompteur);
		  	}
       		else {
		  		rt_mutex_acquire(&mutexCompteur, TM_INFINITE);
		          compteur++;
		          rt_printf("twatchdog : compteur : %d\n", compteur);
		          rt_mutex_release(&mutexCompteur);
       		}
		     message = d_new_message();
		     message->put_state(message, status);
		     rt_printf("twatchdog : Envoi message\n");
		     if (write_in_queue(&queueMsgGUI, message, sizeof (DMessage)) < 0) {
		         message->free(message);
		     }    	      
        }	
}


void connection_perdue(void * arg) {
	unsigned long mask_ret;
	DMessage *message;
	int seuil = 5;

	rt_printf("connexion_perdue : Debut de l'éxecution de periodique à 50ms\n");
	rt_task_set_periodic(NULL, TM_NOW, 100000000); //périodique de 50ms
	
	int ok = 0;
	while (1) {

	    rt_event_wait(&ev_desc,EVENT_WAIT_MASK,&mask_ret,EV_ANY,TM_INFINITE);
		rt_task_sleep(1000000000);
		ok = 0;
		// Boucle bloquante tant que compteur < 3
		while (!ok) {
			rt_task_wait_period(NULL);

			rt_mutex_acquire(&mutexCompteur, TM_INFINITE) ; 
			if (compteur>seuil) ok=1;			
			rt_printf("tcoperdue : compteur = %d\n", compteur) ; 
			rt_mutex_release(&mutexCompteur) ;			 
		}
		rt_printf("/! La connexion a été perdue !\n");
     	message = d_new_message();
		message->put_state(message, STATUS_ERR_TIMEOUT); 
 		if (write_in_queue(&queueMsgGUI, message, sizeof (DMessage)) < 0) {
			 message->free(message);
		}    
		robot->stop(robot);
		robot->close_com(robot);
		rt_mutex_acquire(&mutexCompteur, TM_INFINITE) ;
		compteur = 0;
		rt_mutex_release(&mutexCompteur) ;			 		
		rt_event_clear(&ev_desc,EVENT_WAIT_MASK,&mask_ret);	
	}	
	
}

void acquisition_image (void * arg) {
	int status;
	DMessage * message ; 
	DCamera * camera = d_new_camera() ;
	DJpegimage * jpegimage;
	DPosition * position = d_new_position() ; 
	DImage *imageLoc = d_new_image(); 
	camera-> open(camera) ; 
	rt_printf("tacquisition : Debut de l'éxecution de periodique à 600ms\n");
	rt_task_set_periodic(NULL, TM_NOW, 600000000);
	
	rt_sem_v(&semImage) ; 	
	while(1) {
		rt_printf("tacquisition : Attente du sémaphore semConnectionMoniteur\n");
		rt_sem_p(&semConnectionMoniteur, TM_INFINITE);
		rt_sem_p(&semImage, TM_INFINITE) ; 
		rt_task_wait_period(NULL);
		rt_printf("tacquisition : Activation périodique\n") ; 
		
		camera->get_frame(camera,imageLoc);	
		
		rt_mutex_acquire(&mutexImage, TM_INFINITE) ; 
		image=imageLoc ; 
		rt_mutex_release(&mutexImage) ; 
		
		rt_mutex_acquire(&mutexPosition, TM_INFINITE) ; 
		
		
		if (computePosition == 1) {

			rt_mutex_acquire(&mutexImage, TM_INFINITE) ; 
			position = image->compute_robot_position(image,NULL); 
			d_imageshop_draw_position(image,position);
			rt_mutex_release(&mutexImage) ; 
			rt_printf("tacquisition : Position calculée\n") ; 
		
			if (position != NULL) {
				message = d_new_message();
				message->put_position(message,position);
				rt_printf("tacquisition : Envoi position -------------\n");
				if (write_in_queue(&queueMsgGUI, message, sizeof (DMessage)) < 0) {
					message->free(message);
				}
			}
		
		}
		rt_mutex_release(&mutexPosition) ;
		jpegimage = d_new_jpegimage() ; 

		rt_mutex_acquire(&mutexImage, TM_INFINITE) ; 
		jpegimage->compress(jpegimage,image); 
		rt_mutex_release(&mutexImage) ; 
		
		message = d_new_message();
		message->put_jpeg_image(message,jpegimage);	
		rt_printf("tacquisition : Envoi message\n");
		if (write_in_queue(&queueMsgGUI, message, sizeof (DMessage)) < 0) {
			message->free(message);
		}
		
		jpegimage->free(jpegimage) ; 
		rt_sem_v(&semImage) ; 
		rt_sem_v(&semConnectionMoniteur);
	}
	imageLoc->free(imageLoc) ; 
	position->free(position) ; 
	camera->free(camera) ; 
}

void find_arena(void * arg) {
	int status;
	DMessage * message ;
	DJpegimage * jpegimage ;
	DImage *imageLoc = d_new_image() ; 
	
	printf("tfind_arena : On est dans find arena\n");	
	
	while(1) {
	
		printf("tfind_arena : Attente du sémaphore semArena\n");
		rt_sem_p(&semArena, TM_INFINITE);
		printf("tfind_arena : Activation périodique\n");	
		

				
		rt_mutex_acquire(&mutexImage, TM_INFINITE) ; 
		imageLoc = image ;
		rt_mutex_release(&mutexImage) ; 
		
		arena = imageLoc->compute_arena_position(imageLoc) ;		
		d_imageshop_draw_arena(imageLoc, arena) ; 
		
		jpegimage = d_new_jpegimage();	
		jpegimage->compress(jpegimage,imageLoc); 
		
		message = d_new_message();
		message->put_jpeg_image(message,jpegimage);
		rt_printf("tfind_arena : Envoi message\n");
		if (write_in_queue(&queueMsgGUI, message, sizeof (DMessage)) < 0) {
			message->free(message);
		}
		jpegimage->free(jpegimage) ;  
		rt_sem_v(&semArena);
	} 
	imageLoc->free(imageLoc) ;


}


int write_in_queue(RT_QUEUE *msgQueue, void * data, int size) {
    void *msg;
    int err;

    msg = rt_queue_alloc(msgQueue, size);
    memcpy(msg, &data, size);

    if ((err = rt_queue_send(msgQueue, msg, sizeof (DMessage), Q_NORMAL)) < 0) {
        rt_printf("Error msg queue send: %s\n", strerror(-err));
    }
    rt_queue_free(&queueMsgGUI, msg);

    return err;
}
