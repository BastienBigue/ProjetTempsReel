/*
 * File:   global.h
 * Author: pehladik
 *
 * Created on 21 avril 2011, 12:14
 */

#include "global.h"

RT_TASK tServeur;
RT_TASK tconnect;
RT_TASK tmove;
RT_TASK tenvoyer;
RT_TASK twatchdog;
RT_TASK tbattery;
RT_TASK tconnectionperdue;
RT_TASK tacquisition;
RT_TASK tfind_arena;


RT_MUTEX mutexEtat;
RT_MUTEX mutexMove;
RT_MUTEX mutexCompteur;
RT_MUTEX mutexPosition;
RT_MUTEX mutexImage;

RT_SEM semConnecterRobot;
RT_SEM semConnectionMoniteur ; 
RT_SEM semConnectionOK ; 
RT_SEM semImage ; 
RT_SEM semArena ; 


RT_QUEUE queueMsgGUI;

RT_EVENT ev_desc;

int etatCommMoniteur = 1;
int computePosition = 0 ; 
int compteur = 0 ; 

DRobot *robot;
DMovement *move;
DServer *serveur;
DImage *image; 
DArena *arena = NULL;


int MSG_QUEUE_SIZE = 10;

int PRIORITY_TFINDARENA = 5;
int PRIORITY_TACQUISITION = 5;//discutable, à décider
int PRIORITY_TMOVE = 10;
int PRIORITY_TWATCHDOG = 10;
int PRIORITY_TBATTERY = 10 ; //discutable, à décider
int PRIORITY_TCONNECT = 50;
int PRIORITY_TCONNECTIONPERDUE = 25;	
int PRIORITY_TENVOYER = 25;
int PRIORITY_TSERVEUR = 30;





